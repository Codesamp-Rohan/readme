export default function EditorPane() {
  return (
    <section className="flex-1 border-r border-border bg-background p-6">
      <div className="mb-4 flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold">Editor</h2>
          <p className="text-sm text-muted-foreground">
            Customize your README content.
          </p>
        </div>
      </div>

      <div className="space-y-4">
        <div className="rounded-2xl border border-border bg-secondary p-4">
          <label className="mb-2 block text-sm font-medium">
            Project Title
          </label>

          <input
            placeholder="Enter project title"
            className="w-full rounded-xl border border-border bg-background px-4 py-3 outline-none transition-all focus:ring-2 focus:ring-primary"
          />
        </div>

        <div className="rounded-2xl border border-border bg-secondary p-4">
          <label className="mb-2 block text-sm font-medium">
            Description
          </label>

          <textarea
            rows={8}
            placeholder="Write something amazing..."
            className="w-full resize-none rounded-xl border border-border bg-background px-4 py-3 outline-none transition-all focus:ring-2 focus:ring-primary"
          />
        </div>
      </div>
    </section>
  );
}