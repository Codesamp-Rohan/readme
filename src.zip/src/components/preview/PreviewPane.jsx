export default function PreviewPane() {
  return (
    <section className="hidden w-[40%] bg-muted/30 p-6 xl:block bg-[--foreground]">
      <div className="h-full overflow-auto shadow-sm">
        <div className="prose prose-invert max-w-none">
          <h1>🚀 ReadMD</h1>

          <p>
            Create beautiful and professional GitHub README files with a
            modern visual editor.
          </p>

          <h2>✨ Features</h2>

          <ul>
            <li>Live preview</li>
            <li>Drag & drop sections</li>
            <li>Markdown export</li>
            <li>Modern themes</li>
          </ul>
        </div>
      </div>
    </section>
  );
}