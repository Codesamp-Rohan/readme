const sections = [
  "Hero",
  "About",
  "Skills",
  "Projects",
  "Stats",
  "Socials",
];

export default function Sidebar() {
  return (
    <aside className="hidden w-64 border-r border-border bg-[--foreground] p-4 lg:block">
      <div className="mb-6">
        <h2 className="text-sm font-semibold">Sections</h2>
        <p className="text-xs text-muted-foreground">
          Drag and customise blocks.
        </p>
      </div>

      <div className="space-y-1">
        {sections.map((section) => (
          <button
            key={section}
            className="w-full bg-secondary px-2 py-1 text-left text-sm transition-all hover:bg-accent"
          >
            {section}
          </button>
        ))}
      </div>
    </aside>
  );
}